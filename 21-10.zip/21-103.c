#include<stdio.h>
int main(){
     int X;
     int Y;
     printf("X=\n");
     scanf("%d",&X);
     printf("Y=\n");
     scanf("%d",&Y);
     printf("ans= %d",(X+Y)^2);
     return 0;


}