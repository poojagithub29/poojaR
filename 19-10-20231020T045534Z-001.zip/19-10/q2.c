#include<stdio.h>
int main(){
    int a,b;
    printf("hight\n");
    scanf("%d,",&a);
    
 printf("width\n");
    scanf("%d,",&b);
    printf("area of a rectangle %d",a*b);
    return 0;

}