#include<stdio.h>
int main(){
    const float pi=3.14;

    int a;
    printf("area of circle\n");
    scanf("%d",&a);
    printf("ans %.2f",pi*a*a);
  return 0;




}