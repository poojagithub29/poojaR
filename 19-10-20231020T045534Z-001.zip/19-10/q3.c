#include<stdio.h>
int main(){
    int b,h;

    printf("enter the value of b");
    scanf("%d",&b);
    printf("enter the value of h");
    scanf("%d",&h);
    printf("area %d",b*h/2);
    return 0;

}